<template>
  <div :class="[className, theme]">
    <div :class="`${className}__header`">
      <span :class="`${className}__header__lang`">{{ lang }}</span>
      <span :class="`${className}__header__copy__wrapper`" @click="clickCopyHandler">
        <span :class="`${className}__header__copy`">复制</span>
      </span>
    </div>
    <pre :class="[`${className}__body`, 'hljs']">
      <code :part="`${className}__code`" v-html="codeHTML"></code>
    </pre>
  </div>
</template>

<script setup>

import hljs from 'highlight.js'
import { escape } from 'lodash-es'
import { onMounted, ref } from 'vue'

const className = `ec-chat__text__markdown__code`

const props = defineProps({
  'data-lang': {
    type: String,
    default: ''
  },
  'data-code': {
    type: String,
    default: ''
  },
  'data-theme': {
    type: String,
    default: ''
  }
})

const emit = defineEmits(['code_copy'])

const msgInstance = ref(null)
const codeHTML = ref(null)

const lang = ref(props['data-lang'])
const theme = ref(props['data-theme'])

onMounted(() => {
  const code = props['data-code']
  // 解析代码HTML
  codeHTML.value = escape(code)
  if (lang.value && hljs.getLanguage(lang.value)) {
    codeHTML.value = hljs.highlight(code, {
      language: lang.value,
      ignoreIllegals: true
    }).value
  }
})

const clickCopyHandler = () => {
  const code = props['data-code'] || ''
  const langVal = props['data-lang']

  // 派发事件到外层
  emit('code_copy', { code, lang: langVal })
  alert.success('模拟复制成功')
  // navigator.clipboard
  //   .writeText(code)
  //   .then(() => {
  //     msgInstance.value = alert.success('复制成功')
  //   })
  //   .catch(() => {
  //     msgInstance.value = alert.success('复制失败，请手动复制')
  //   })
}
</script>
