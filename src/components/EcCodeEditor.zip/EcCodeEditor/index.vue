<template>
  <div class="ec-code-editor" :style="{ height: _height }">
    <textarea ref="textareaRef"></textarea>
  </div>
</template>

<script setup>
// 框架
import CodeMirror from 'codemirror'
import 'codemirror/lib/codemirror.css'

// 主题
import 'codemirror/theme/idea.css'
import 'codemirror/theme/darcula.css'

// 功能
import 'codemirror/addon/selection/active-line'

// 语言
import 'codemirror/mode/javascript/javascript'
import 'codemirror/mode/sql/sql'

// 使用 defineModel 简化 v-model
const model = defineModel({
  type: String,
  default: ''
})

// 定义 props（除 modelValue 外的其他 prop）
const props = defineProps({
  mode: {
    type: String,
    default: 'javascript'
  },
  height: {
    type: [String, Number],
    default: 320
  },
  options: {
    type: Object,
    default: () => ({})
  },
  theme: {
    type: String,
    default: 'idea'
  },
  readOnly: {
    type: Boolean,
    default: false
  }
})

// refs
import { ref, computed, onMounted, watch } from 'vue'

const textareaRef = ref(null)
const coder = ref(null)

// 合并配置
const opt = computed(() => ({
  theme: props.theme,
  styleActiveLine: true,
  lineNumbers: true,
  lineWrapping: false,
  tabSize: 4,
  indentUnit: 4,
  indentWithTabs: true,
  mode: props.mode,
  readOnly: props.readOnly,
  ...props.options
}))

// 高度计算
const _height = computed(() => {
  return typeof props.height === 'number' ? `${props.height}px` : props.height
})

// 初始化 CodeMirror
onMounted(() => {
  coder.value = CodeMirror.fromTextArea(textareaRef.value, opt.value)

  // 监听内容变化
  coder.value.on('change', (cm) => {
    const newValue = cm.getValue()
    model.value = newValue
  })

  // 初始值同步
  if (model.value) {
    coder.value.setValue(model.value)
  }
})

// 监听外部 model 变化（如父组件更新 v-model）
watch(model, (newVal) => {
  if (coder.value && coder.value.getValue() !== newVal) {
    coder.value.setValue(newVal)
  }
})

// 可选：暴露 coder 实例（如果父组件需要）
defineExpose({ coder })
</script>

<style lang="scss" scoped>
.ec-code-editor {
  font-size: 14px;
  border: 1px solid #ddd;
  line-height: 1.5;

  ::v-deep(.CodeMirror) {
    height: 100%;
  }
}
</style>
