<template>
  <div class="ec-code-editor" :style="{ height: _height }">
    <textarea ref="textareaRef"></textarea>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, nextTick, onBeforeUnmount } from 'vue'
import { markRaw } from 'vue'
import CodeMirror from 'codemirror'
import 'codemirror/lib/codemirror.css'
import 'codemirror/theme/idea.css'
import 'codemirror/theme/darcula.css'
import 'codemirror/addon/selection/active-line'
import 'codemirror/mode/javascript/javascript'
import 'codemirror/mode/sql/sql'
import JSBeautify from 'js-beautify'
defineOptions({
  name: 'EcCodeEditor',
})

const props = defineProps({
  mode: {
    type: String,
    default: 'javascript',
  },
  height: {
    type: [String, Number],
    default: 320,
  },
  options: {
    type: Object,
    default: () => ({}),
  },
  theme: {
    type: String,
    default: 'idea',
  },
  readOnly: {
    type: Boolean,
    default: false,
  },
})

const model = defineModel({
  type: String,
  default: '',
})

const textareaRef = ref(null)
const coder = ref(null)


const _height = computed(() => {
  return typeof props.height === 'number' ? `${props.height}px` : props.height
})
const config = computed(() => ({
  theme: props.theme,
  styleActiveLine: true,
  lineNumbers: true,
  lineWrapping: false,
  tabSize: 4,
  indentUnit: 4,
  indentWithTabs: true,
  mode: props.mode,
  readOnly: props.readOnly,
  ...props.options,
}))


watch(() => model.value, (val) => {
  if (coder.value && val !== coder.value.getValue()) {
    coder.value.setValue(val)
  }
})

const formatStrInJson = (val) => {
  return JSON.stringify(JSON.parse(val), null, 4)
}
const formatStrInBeautify = () => {
  const value = coder.value.getValue()
  const mode = coder.value.getOption('mode')
  const code = JSBeautify.js(value, { mode, indent_size: 2 })
  coder.value.setValue(code)
}
const init = () => {
  try {
    coder.value = markRaw(CodeMirror.fromTextArea(textareaRef.value, config.value))
    coder.value.on('change', (cm) => model.value = cm.getValue())
    if (model.value) {
      coder.value.setValue(model.value)  // 设置初始内容
      formatStrInBeautify()
    }

  } catch (error) {
    console.error('编辑器初始化失败:', error)
  }
}
onMounted(async () => {
  await nextTick()
  init()
})
onBeforeUnmount(() => {
  if (coder.value) {
    coder.value.toTextArea()
    coder.value = null
  }
})

defineExpose({
  formatStrInJson,
  formatStrInBeautify,
  getEditor: () => coder.value,
  focus: () => coder.value?.focus(),
  refresh: () => coder.value?.refresh(),
})
</script>

<style lang="scss" scoped>
  .ec-code-editor {
    font-size: var(--el-font-size-base);
    border: 1px solid var(--el-border-color);
    line-height: 1.5;
    :deep(.CodeMirror) {
      height: 100%;
    }
  }
</style>
