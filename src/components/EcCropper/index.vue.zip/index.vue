<template>
  <div>
    <cropper-canvas ref="croppercanvas" :background="canvas.background" :disabled="canvas.disabled"
      :hidden="canvas.hidden" :scale-step="canvas.scaleStep" :theme-color="canvas.themeColor"
      style="height: 100%; width: 100%;">
      <cropper-image ref="cropperImage" :hidden="image.hidden" :rotatable="image.rotatable" :scalable="image.scalable"
        :skewable="image.skewable" :translatable="image.translatable" :initial-center-size="image.initialCenterSize"
        :src="image.src" :alt="image.alt" crossorigin="anonymous" @transform="onImageTransform" />
      <cropper-shade :hidden="shade.hidden" :theme-color="shade.themeColor" />
      <cropper-handle :action="handle.action" :hidden="handle.hidden" :plain="handle.plain"
        :theme-color="handle.themeColor" />
      <cropper-selection id="cropperSelection" ref="cropperSelection" :x="selection.x" :y="selection.y"
        :width="selection.width" :height="selection.height" :aspect-ratio="selection.aspectRatio"
        :initial-coverage="selection.initialCoverage" :hidden="selection.hidden"
        :initial-aspect-ratio="selection.initialAspectRatio" :movable="selection.movable"
        :resizable="selection.resizable" :zoomable="selection.zoomable" :multiple="selection.multiple"
        :keyboard="selection.keyboard" :outlined="selection.outlined" :precise="selection.precise"
        :dynamic="selection.dynamic" @change="onSelectionChange">
        <cropper-grid :hidden="grid.hidden" :rows="grid.rows" :columns="grid.columns" :bordered="grid.bordered"
          :covered="grid.covered" :theme-color="grid.themeColor" />
        <cropper-crosshair :hidden="crosshair.hidden" :centered="crosshair.centered"
          :theme-color="crosshair.themeColor" />

        <cropper-handle v-for="subhandle in handles" :key="subhandle.action" :action="subhandle.action"
          :hidden="subhandle.hidden" :theme-color="subhandle.themeColor" />
      </cropper-selection>
    </cropper-canvas>
  </div>
</template>

<script setup>

import { computed, ref } from 'vue'
import 'cropperjs'
const ready = ref(true)
const canvas = ref({
  hidden: false,
  background: true,
  disabled: false,
  scaleStep: 0.1,
  themeColor: 'var(--el-color-primary)',
})

const handle = ref({
  hidden: false,
  action: 'select',
  plain: true,
  themeColor: 'rgba(51, 153, 255, 0.5)',
})
const image = ref({
  hidden: false,
  initialCenterSize: 'contain',
  rotatable: true,
  scalable: true,
  skewable: true,
  translatable: true,
  src: `https://fuss10.elemecdn.com/1/34/19aa98b1fcb2781c4fba33d850549jpeg.jpeg`,
  alt: 'The image to crop',
})
const grid = ref({
  hidden: false,
  rows: 3,
  columns: 3,
  bordered: true,
  covered: true,
  themeColor: 'rgba(238, 238, 238, 0.5)',
})
const crosshair = ref({
  hidden: false,
  centered: true,
  themeColor: 'rgba(238, 238, 238, 0.5)',
})
const shade = ref({
  themeColor: 'rgba(0, 0, 0, 0.65)',
})
const handles = ref([
  {
    hidden: false,
    action: 'move',
    themeColor: 'rgba(255, 255, 255, 0.35)',
  },
  {
    hidden: false,
    action: 'n-resize',
    themeColor: 'var(--el-color-primary)',
  },
  {
    hidden: false,
    action: 'e-resize',
    themeColor: 'var(--el-color-primary)',
  },
  {
    hidden: false,
    action: 's-resize',
    themeColor: 'var(--el-color-primary)',
  },
  {
    hidden: false,
    action: 'w-resize',
    themeColor: 'var(--el-color-primary)',
  },
  {
    hidden: false,
    action: 'ne-resize',
    themeColor: 'var(--el-color-primary)',
  },
  {
    hidden: false,
    action: 'nw-resize',
    themeColor: 'var(--el-color-primary)',
  },
  {
    hidden: false,
    action: 'se-resize',
    themeColor: 'var(--el-color-primary)',
  },
  {
    hidden: false,
    action: 'sw-resize',
    themeColor: 'var(--el-color-primary)',
  },
])
const selection = ref({
  hidden: false,
  x: undefined,
  y: undefined,
  width: undefined,
  height: undefined,
  aspectRatio: undefined,
  initialAspectRatio: undefined,
  initialCoverage: 0.5,
  dynamic: false,
  movable: true,
  resizable: true,
  zoomable: false,
  multiple: false,
  keyboard: false,
  outlined: false,
  precise: false,
})
const cropperCanvas = ref()
const cropperSelection = ref()

const getCropData = async (cb, type = 'image/jpeg') => {
  const canvas = await cropperSelection.value.$toCanvas()
  cb(canvas.toDataURL(type, 1))
}
const getCropBlob = async (cb, type = 'image/jpeg') => {
  const canvas = await cropperSelection.value.$toCanvas()
  canvas.toBlob((blob) => {
    cb(blob)
  }, type, 1)
}
const getCropFile = async (cb, fileName = 'fileName.jpg', type = 'image/jpeg') => {
  const canvas = await cropperSelection.value.$toCanvas()
  canvas.toBlob((blob) => {
    const file = new File([blob], fileName, { type: type })
    cb(file)
  }, type, 1)
}
defineExpose({
  getCropData,
  getCropBlob,
  getCropFile
})
</script>

