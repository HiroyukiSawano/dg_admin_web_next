// markdown-it-plugin-mermaid.js

import * as mermaid from 'mermaid'

export default function mermaidPlugin(md, opts) {
  md.mermaid = mermaid

  opts = opts || {
    theme: 'default',
    securityLevel: 'strict'
  }

  if (typeof mermaid.run === 'function') {
    mermaid.run({
      initializeOnlyOnce: true,
      ...opts
    })
  } else if (typeof mermaid.initialize === 'function') {
    // fallback for older versions
    mermaid.initialize(opts)
  }

  const temp = md.renderer.rules.fence.bind(md.renderer.rules)

  md.renderer.rules.fence = (tokens, idx, options, env, slf) => {
    const token = tokens[idx]
    const code = token.content.trim()

    if (token.info === 'mermaid') {
      return `<div class="mermaid">${code}</div>`
    }

    const firstLine = code.split(/\n/)[0]?.trim() || ''
    if (
      firstLine === 'gantt' ||
      firstLine === 'sequenceDiagram' ||
      /^graph\s+(TB|BT|RL|LR|TD);?$/.test(firstLine)
    ) {
      return `<div class="mermaid">${code}</div>`
    }

    return temp(tokens, idx, options, env, slf)
  }
}
