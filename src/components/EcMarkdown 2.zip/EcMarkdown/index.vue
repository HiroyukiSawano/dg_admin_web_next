<template>
  <div :class="baseClass">
    <div ref="mdRef" :class="`${baseClass}__markdown`"></div>
  </div>
</template>

<script setup>
import ChatMdCode from './md/chat-md-code.vue'
import { defineAsyncComponent } from 'vue'

// 注册代码块组件
const TChatMdCode = defineAsyncComponent(() => import('./md/chat-md-code.vue'))


import { escape, merge } from 'lodash-es'

import { ref, onMounted, watch, computed } from 'vue'

import { AddPartHook } from './md/utils'

// import styles from '../style/chat-content.less'
// import codeStyles from '../style/md/chat-md-code.less'
import { Cherry } from './cherry-init'


const props = defineProps({
  content: {
    type: String,
    default: ''
  },
  options: {
    type: Object,
    default: () => ({})
  }
})

const baseClass = computed(() => `ec-chat__text`)

const mdRef = ref(null)
const md = ref(null)
const isMarkdownInit = ref(false)

const markdownOptions = {
  engine: {
    global: {
      flowSessionContext: true,
    },
    syntax: {
      table: {
        selfClosing: true,
        enableChart: true
      },
      link: {
        target: '_blank',
      },
      // codeBlock: {
      //   customRenderer: {
      //     all: {
      //       render: (code, _sign, _cherry, lang) =>
      //         `<t-chat-md-code key="${_sign}" data-lang="${lang}" data-code="${escape(code)}" />`,
      //     },
      //   },
      // },
    },
    customSyntax: {
      AddPart: {
        syntaxClass: AddPartHook,
        before: 'frontMatter',
      },
    },
  },
  // toolbars: {
  //   toolbar: false,
  //   toc: false,
  //   showToolbar: false,
  // },
  // editor: {
  //   defaultModel: 'previewOnly',
  // },
  // previewer: {
  //   enablePreviewerBubble: false,
  // },
}

const initMarkdown = () => {
  return new Promise((resolve) => {
    isMarkdownInit.value = false
    // const customCodeBlock = props.options.engine?.syntax?.codeBlock
    // const customCodeBlockRenderer = typeof customCodeBlock === 'object' ? customCodeBlock?.customRenderer : undefined

    // const defaultCodeBlockRenderer = {
    //   all: {
    //     render: (code, _sign, _cherry, lang) =>
    //       `<t-chat-md-code key="${_sign}" data-lang="${lang}" data-code="${escape(code)}" data-theme="${
    //         markdownOptions.themeSettings?.codeBlockTheme === 'dark' ? 'dark' : 'light'
    //       }" />`,
    //   },
    // }

    const mergedOptions = merge(markdownOptions, props.options)

    // 确保DOM元素已经存在
    if (!mdRef.value) {
      console.error('Markdown container element not found')
      isMarkdownInit.value = true
      return resolve()
    }

    try {
      md.value = new Cherry({
        ...mergedOptions,
        engine: {
          ...mergedOptions.engine,
          syntax: {
            ...mergedOptions.engine?.syntax,
            // codeBlock: {
            //   customRenderer: { ...defaultCodeBlockRenderer, ...customCodeBlockRenderer },
            // },
          },
        },
        el: mdRef.value,
      })
    } catch (error) {
      console.error('Error initializing Cherry markdown:', error)
    }

    isMarkdownInit.value = true
    resolve()
  })
}

const getTextInfo = () => {
  const { content } = props
  if (typeof content !== 'string') return
  parseMarkdown(content || ' ')
}

const parseMarkdown = (markdown) => {
  if (!isMarkdownInit.value || !markdown) return ''
  md.value?.setMarkdown(markdown)
}

onMounted(async () => {
  await initMarkdown()
  getTextInfo()
})

watch(() => props.content, (newContent) => {
  getTextInfo()
}, { immediate: true })
</script>
