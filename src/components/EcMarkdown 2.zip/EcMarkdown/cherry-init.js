
// import Cherry from 'cherry-markdown/dist/cherry-markdown.core'
import Cherry from 'cherry-markdown';
import CherryCodeBlockMermaidPlugin from 'cherry-markdown/dist/addons/cherry-code-block-mermaid-plugin'
import CherryTableEchartsPlugin from 'cherry-markdown/dist/addons/advance/cherry-table-echarts-plugin'

import mermaid from 'mermaid'
import echarts from 'echarts'

// Make echarts available globally for the plugin
window.echarts = echarts

console.log('Echarts imported:', echarts)
console.log('Echarts is object:', typeof echarts === 'object')
console.log('CherryTableEchartsPlugin:', CherryTableEchartsPlugin)
import "cherry-markdown/dist/cherry-markdown.css";
mermaid.initialize({ startOnLoad: false });
Cherry.usePlugin(CherryCodeBlockMermaidPlugin, {
  mermaid,
  mermaidCanvasAppendDom: document.body,
})

Cherry.usePlugin(CherryTableEchartsPlugin, {
  echarts
})
// Cherry.usePlugin(echartsEngine , { echarts });
export { Cherry }
