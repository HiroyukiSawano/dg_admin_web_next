<template>
  <div class="page-padding">
    <el-row :gutter="16">
      <el-col :lg="16">
        <el-card header="裁剪">
          <ec-cropper ref="cropperRef" style="height: 400px;" />
        </el-card>
      </el-col>
      <el-col :lg="8">
        <!-- <el-card header="参数和方法">
          <el-alert title="打开控制台查看输出数据" type="success" style="margin-bottom: 16px;" />
          <el-form label-position="top">
            <el-form-item label="比例">
              <el-select v-model="cropperAspectRatio" placeholder="请选择比例" style="width:100%;">
                <el-option label="自由" :value="0"></el-option>
                <el-option label="1:1" :value="1/1"></el-option>
                <el-option label="4:3" :value="4/3"></el-option>
                <el-option label="16:9" :value="16/9"></el-option>
              </el-select>
              <div class="el-form-item-msg">固定选区或者不固定</div>
            </el-form-item>
            <el-form-item label="压缩率">
              <el-select v-model="cropperCompress" placeholder="请选择压缩率" style="width:100%;">
                <el-option label="0.1" :value="0.1"></el-option>
                <el-option label="0.5" :value="0.5"></el-option>
                <el-option label="1" :value="1"></el-option>
              </el-select>
              <div>图像压缩率，值为：0.1-1</div>
            </el-form-item>
            <el-form-item label="">
              <el-button type="primary" plain @click="getBase64">Base64</el-button>
              <el-button type="primary" plain @click="getBlob">Blob</el-button>
              <el-button type="primary" plain @click="getFile">File</el-button>
            </el-form-item>
          </el-form>
        </el-card> -->
      </el-col>
    </el-row>
  </div>
</template>
<script setup>
import { ref } from 'vue'
import EcCropper from '@/components/EcCropper'
defineOptions({
  name: 'vabCropper',
})
const cropperImage = ref('https://fuss10.elemecdn.com/1/34/19aa98b1fcb2781c4fba33d850549jpeg.jpeg')
const cropperCompress = ref(0.5)
const cropperAspectRatio = ref(0)
const uploadImg = ref('')
const imgData = ref('')
const cropperRef = ref(null)
const getBase64 = () => {
  cropperRef.value.getCropData(data => {
    console.log(data)
  })
}
const getBlob = () => {
  cropperRef.value.getCropBlob(blob => {
    console.log(URL.createObjectURL(blob))
  })
}
const getFile = () => {
  cropperRef.value.getCropFile(file => {
    const a = document.createElement('a')
    a.download = file.name
    a.href = URL.createObjectURL(file)
    a.click()
  }, `file_${Date.now()}.jpg`, 'image/jpeg')
}

</script>

<style lang="scss" scoped>
::v-deep .el-card {
  min-height: 440px;
  margin-bottom: 16px;
  border: 0;
}
</style>
