<template>
  <div class="ec-code-editor" :style="{ height: _height }">
    <div ref="editorRef"></div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, nextTick, onBeforeUnmount } from 'vue'
import { basicSetup } from 'codemirror'
import { EditorView, ViewUpdate } from '@codemirror/view'
import { EditorState } from '@codemirror/state'
import { javascript } from '@codemirror/lang-javascript'
import { oneDark } from '@codemirror/theme-one-dark'
import JSBeautify from 'js-beautify'

defineOptions({
  name: 'EcCodeEditorCM6',
})

const props = defineProps({
  mode: {
    type: String,
    default: 'javascript',
  },
  height: {
    type: [String, Number],
    default: 320,
  },
  options: {
    type: Object,
    default: () => ({}),
  },
  theme: {
    type: String,
    default: 'light',
  },
  readOnly: {
    type: Boolean,
    default: false,
  },
})

const model = defineModel({
  type: String,
  default: '',
})

const editorRef = ref(null)
const editor = ref(null)

// 计算高度
const _height = computed(() => {
  return typeof props.height === 'number' ? `${props.height}px` : props.height
})

// 根据mode获取相应的语言支持扩展
const getLanguageExtension = (mode) => {
  switch (mode) {
    case 'javascript':
    case 'js':
      return javascript()
    // 可以添加更多语言支持
    default:
      return []
  }
}

// 获取主题
const getThemeExtension = (theme) => {
  if (theme === 'dark' || theme === 'darcula') {
    return oneDark
  }
  // 默认使用light主题
  return EditorView.theme({
    '&': {
      height: '100%',
      fontSize: 'inherit',
    },
    '.cm-content': {
      caretColor: '#000',
    },
    '.cm-gutters': {
      backgroundColor: '#f8f9fa',
      color: '#6b7280',
      border: 'none',
    },
    '.cm-activeLineGutter': {
      backgroundColor: '#f0f0f0',
    },
    '.cm-activeLine': {
      backgroundColor: '#f5f5f5',
    },
    '.cm-scroller': {
      fontFamily: 'monospace',
    },
  })
}

// 初始化编辑器
const init = () => {
  try {
    // 创建状态配置
    const state = EditorState.create({
      doc: model.value || '',
      extensions: [
        basicSetup,
        getLanguageExtension(props.mode),
        getThemeExtension(props.theme),
        EditorView.updateListener.of((update) => {
          if (update.docChanged) {
            model.value = update.state.doc.toString()
          }
        }),
        EditorView.readOnly.of(props.readOnly),
        EditorView.lineWrapping,
        EditorView.theme({
          '&': {
            height: '100%',
          },
        }),
        // 应用自定义选项
        ...(Array.isArray(props.options) ? props.options : []),
      ],
    })

    // 创建编辑器视图
    editor.value = new EditorView({
      state,
      parent: editorRef.value,
    })

    // 初始化后格式化代码
    if (model.value) {
      formatStrInBeautify()
    }

  } catch (error) {
    console.error('CodeMirror 6初始化失败:', error)
  }
}

// 格式化JSON字符串
const formatStrInJson = (val) => {
  try {
    const formatted = JSON.stringify(JSON.parse(val), null, 4)
    if (editor.value) {
      const transaction = editor.value.state.update({
        changes: {
          from: 0,
          to: editor.value.state.doc.length,
          insert: formatted,
        },
      })
      editor.value.dispatch(transaction)
    }
    return formatted
  } catch (error) {
    console.error('JSON格式化失败:', error)
    return val
  }
}

// 使用JSBeautify格式化代码
const formatStrInBeautify = () => {
  try {
    if (!editor.value) return
    
    const value = editor.value.state.doc.toString()
    const mode = props.mode
    let code = value
    
    if (mode === 'javascript' || mode === 'js') {
      code = JSBeautify.js(value, { indent_size: 2 })
    } else if (mode === 'json') {
      return formatStrInJson(value)
    }
    
    const transaction = editor.value.state.update({
      changes: {
        from: 0,
        to: editor.value.state.doc.length,
        insert: code,
      },
    })
    editor.value.dispatch(transaction)
  } catch (error) {
    console.error('代码格式化失败:', error)
  }
}

// 监听model值变化
watch(() => model.value, (val) => {
  if (editor.value && val !== editor.value.state.doc.toString()) {
    const transaction = editor.value.state.update({
      changes: {
        from: 0,
        to: editor.value.state.doc.length,
        insert: val,
      },
    })
    editor.value.dispatch(transaction)
  }
})

// 组件挂载时初始化
onMounted(async () => {
  await nextTick()
  init()
})

// 组件卸载前清理
onBeforeUnmount(() => {
  if (editor.value) {
    editor.value.destroy()
    editor.value = null
  }
})

// 暴露方法给父组件
defineExpose({
  formatStrInJson,
  formatStrInBeautify,
  getEditor: () => editor.value,
  focus: () => editor.value?.focus(),
  refresh: () => {
    if (editor.value) {
      editor.value.requestMeasure()
    }
  },
})
</script>

<style lang="scss" scoped>
.ec-code-editor {
  font-size: var(--el-font-size-base);
  border: 1px solid var(--el-border-color);
  line-height: 1.5;
  overflow: hidden;
  
  :deep(.cm-editor) {
    height: 100%;
    width: 100%;
  }
  
  :deep(.cm-scroller) {
    overflow: auto;
  }
}
</style>